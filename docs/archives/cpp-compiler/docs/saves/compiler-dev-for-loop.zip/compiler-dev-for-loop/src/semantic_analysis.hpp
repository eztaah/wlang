#ifndef SEMANTIC_ANALYSIS_HPP
#define SEMANTIC_ANALYSIS_HPP

#include "global.hpp"

void analyzeAST(const NodePtr &node);

#endif // SEMANTIC_ANALYSIS_HPP
