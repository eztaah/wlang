support for cp language


DEV : 

$ sudo dnf install nodejs

$ sudo npm install -g @vscode/vsce

$ vsce package --no-yarn 